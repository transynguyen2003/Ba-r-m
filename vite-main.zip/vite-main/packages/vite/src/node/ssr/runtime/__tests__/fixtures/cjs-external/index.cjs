module.exports = {
  hello: () => 'world',
}
