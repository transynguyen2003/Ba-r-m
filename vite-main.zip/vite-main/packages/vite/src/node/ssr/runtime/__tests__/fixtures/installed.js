export * from 'tinyspy'
