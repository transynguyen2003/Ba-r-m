export default 'module condition'
